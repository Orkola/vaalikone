/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package vaalikone;

import javax.servlet.http.HttpServlet;

/**
 *
 * @author sami1422
 */
public class Count extends HttpServlet {
    
}
